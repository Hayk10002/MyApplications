#pragma once
#include "../../../Other/Processing.hpp"
class DeleteConfirmMenu :public Process
{
};

