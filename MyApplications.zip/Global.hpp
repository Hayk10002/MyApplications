#pragma once
#include <SFML/Graphics.hpp>
#include <Windows.h>
#include "../../../Other/Processing.hpp"
using namespace sf;
using namespace std;
extern const Vector2u WINDOW_RES, SCREEN_RES;
extern RenderWindow window;
extern Procs procs;
extern Texture MainMenuBackground, ButtonsTexture;