#pragma once
class Application
{
};

