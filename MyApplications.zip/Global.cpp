#include "Global.hpp"
RenderWindow window;
Procs procs(window);
const Vector2u WINDOW_RES = Vector2u(1000, 600), SCREEN_RES = Vector2u(GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
Texture MainMenuBackground, ButtonsTexture;
