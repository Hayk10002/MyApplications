#pragma once
#include "../../../Other/Processing.hpp"
class Delete_Menu :public Process
{
};

