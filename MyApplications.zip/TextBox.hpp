#pragma once
#include "../../../Other/Processing.hpp"
class TextBox :public Process
{

};
