#pragma once
#include "../../../Other/Processing.hpp"
class ApplListMenu :public Process
{
};

